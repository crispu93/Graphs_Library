import java.util.HashMap;
//import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Graph {
    HashMap<String, Node> nodes;
    HashMap<String, Edge> edges;
    boolean directed;
    boolean self;

    public Graph(boolean directed, boolean self) {
        this.nodes = new HashMap<String, Node> ();
        this.edges = new HashMap<String, Edge> ();
        this.directed = directed;
        this.self = self;
    }

    public boolean isDirected() {
        return this.directed;
    }

    public boolean isMultiGraph(){
        return this.self;
    }

    public boolean isEdge(String n1, String n2){
        return this.edges.containsKey(n1 + "-" + n2);
    }
    public void addNode(String label){
        Node aux = new Node(label);
        this.nodes.put(label, aux);
    }

    public int getDegree(String label){
        return this.nodes.get(label).getDegree();
    }

    public void updateNode(String label) {
        this.nodes.get(label).upDegree();
    }

    // Create an edge if two nodes exists
    public void addEdge(String n1, String n2) {
        if (this.nodes.containsKey(n1) && this.nodes.containsKey(n2)){
            Edge aux = new Edge(n1,n2);
            this.updateNode(n2);
            this.edges.put(aux.getId(), aux);
            if( this.directed ){
                Edge aux2 = new Edge(n2,n1);
                this.updateNode(n1);
                this.edges.put(aux2.getId(), aux2);
            }
        }
    }

    public void printEdges(){
        this.edges.forEach((key,value) -> System.out.println( key ));
    }

    public void graphToFile(String filename) throws IOException {
        FileWriter file = new FileWriter(filename);
        
        /*this.nodes.forEach((key,value) ->  {
            try {
                file.write(value.getLabel() + ";" + value.getLabel() + "\n");
                
            } catch(IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
            
        });*/

        this.edges.forEach((key,value) ->  {
            try {
                file.write(value.getFirst() + ";" + value.getSecond() + "\n");
                
            } catch(IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
            
        });
        file.close();
    }

    public static void main(String[] args){
        Graph g = new Graph(true, true);
        g.addNode("n1");
        g.addNode("n2");
        g.addNode("n3");
        g.addEdge("n1", "n2");
        g.addEdge("n3", "n1");
        if(g.isEdge("n1","n2"))
            System.out.println("Si es arista");
        g.printEdges();
        try {
            g.graphToFile("test.csv");
        }catch(IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        
        System.out.println(g.getDegree("n3"));
    }
}